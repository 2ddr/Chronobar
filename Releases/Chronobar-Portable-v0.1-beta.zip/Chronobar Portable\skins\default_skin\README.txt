Структура скина
===============

Скин — это папка в каталоге Skins/ рядом с timer2.exe.
Внешний вид задаётся обычными HTML + CSS, логику (таймер, клиенты,
меню) добавляет приложение. JavaScript в скине не выполняется.

Структура:
  Skins/
  └── my_skin/
      ├── skin.json          # Описание скина (обязательный)
      ├── skin.html          # Разметка (обязательный)
      ├── skin.css           # Стили (обязательный)
      └── elements/          # Графика; пути в CSS — относительные

Графика default_skin:
      ├── background.png           # Фон всего окна (400×16)
      ├── drag_zone.png            # Зона перетаскивания (12×16)
      ├── combo.png                # Фон поля с именем, повторяется по X (250×16)
      ├── combo_normal.png         # Правая часть со стрелкой — normal (30×16)
      ├── combo_hover.png          # — hover (30×16)
      ├── combo_pressed.png        # — pressed (30×16)
      ├── settings_normal.png      # Кнопка настроек — normal (16×16, по центру 18px)
      ├── settings_hover.png       # — hover
      ├── settings_pressed.png     # — pressed
      ├── timer_bg_normal.png      # Фон кнопки (stopped, normal)
      ├── timer_bg_hover.png       # Фон кнопки (stopped, hover)
      ├── timer_bg_pressed.png     # Фон кнопки (stopped, pressed)
      ├── timer_running_bg_normal.png   # Фон кнопки (running, normal)
      ├── timer_running_bg_hover.png    # Фон кнопки (running, hover)
      └── timer_running_bg_pressed.png  # Фон кнопки (running, pressed)

Графика может быть любой — имена и набор файлов определяет skin.css.

skin.json
---------
{
    "name": "Название скина",      # показывается в меню «Скин»
    "version": "1.0",
    "author": "",
    "description": "Описание скина",
    "window": { "width": 400, "height": 16 }   # размер окна
}

Контракт skin.html
------------------
Приложение берёт содержимое <body> и подключает skin.css.
Элементы находятся по классам (все обязательны):
  .drag-zone     — за неё окно перетаскивается
  .combo         — клик открывает меню выбора клиента
  .combo-text    — приложение пишет сюда имя текущего клиента
  .timer-btn     — клик: старт/стоп; текст — время в формате «ЧЧ:ММ СС»
  .settings-btn  — клик открывает меню настроек

Состояния, которые ставит приложение:
  .timer-btn.running — таймер идёт
Состояния мыши — стандартные :hover и :active.

Время выводится текстом; шрифт, размер и цвет задаются в skin.css
(в default_skin — Consolas 11px). Моноширинный шрифт рекомендуется,
чтобы цифры не «прыгали».

Кнопки таймера
--------------
Кнопка под часами имеет 6 состояний:

  STOPPED (когда таймер остановлен):
    - timer_bg_normal   — нормальное состояние
    - timer_bg_hover    — мышь наведена
    - timer_bg_pressed  — кнопка нажата

  RUNNING (когда таймер идёт):
    - timer_running_bg_normal   — нормальное состояние
    - timer_running_bg_hover    — мышь наведена
    - timer_running_bg_pressed  — кнопка нажата

В default_skin все изображения используются в масштабе 1:1 — без растяжения.

Создание своего скина
---------------------
1. Скопируйте папку default_skin в Skins/ под новым именем.
2. Измените name в skin.json, графику в elements/ и стили в skin.css.
3. Выберите скин в меню настроек (шестерёнка → Скин).

Технические требования
----------------------
- Размер окна — из skin.json (по умолчанию 400×16)
- Форматы графики: PNG (рекомендуется с прозрачностью), JPG, GIF, SVG
- Все файлы — в кодировке UTF-8
- Внешние ссылки (http://...) и <script> не используются
